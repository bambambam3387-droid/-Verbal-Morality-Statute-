package com.example.profanityfine

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

class ProfanityService : Service(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildNotification("Listening for Verbal Morality Statute violations…"))

        tts = TextToSpeech(this, this)

        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        startRecognizer()
    }

    private fun startRecognizer() {
        stopRecognizer()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { startListening() }
                override fun onResults(results: Bundle) {
                    val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleTranscript(text)
                    startListening()
                }
                override fun onPartialResults(partialResults: Bundle) {
                    val text = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleTranscript(text)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(recognizerIntent)
        }
    }

    private fun startListening() {
        speechRecognizer?.stopListening()
        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun stopRecognizer() {
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun handleTranscript(text: String) {
        if (text.isBlank()) return
        if (ProfanityDetector.containsProfanity(text)) {
            val prefs = getSharedPreferences("pf", Context.MODE_PRIVATE)
            val name = prefs.getString("name", "John Replogle") ?: "John Replogle"
            val credits = max(0, prefs.getInt("credits", 50))
            val newCredits = max(0, credits - 1)
            val timestamp = SimpleDateFormat("HH:mm:ss yyyy-MM-dd", Locale.getDefault()).format(Date())
            val entry = "$timestamp - $name fined 1 credit for profanity."

            val log = prefs.getStringSet("citations", mutableSetOf())!!.toMutableSet()
            log.add(entry)
            prefs.edit().putStringSet("citations", log).putInt("credits", newCredits).apply()

            playChime()
            val message = "Be well. $name, you are fined one credit for a violation of the Verbal Morality Statute."
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "fine")
            updateNotification("Last violation: −1 credit | Remaining credits: $newCredits")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("pf_channel", "Profanity Fine", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, "pf_channel")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Verbal Morality Statute Monitor")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, buildNotification(text))
    }

    private fun playChime() {
        try {
            val notif = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            val r = android.media.RingtoneManager.getRingtone(applicationContext, notif)
            r.play()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        stopRecognizer()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        tts?.language = Locale.getDefault()
        tts?.setSpeechRate(0.9f)
        tts?.setPitch(1.05f)
    }
}
