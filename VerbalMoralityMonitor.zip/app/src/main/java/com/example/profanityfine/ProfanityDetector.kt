package com.example.profanityfine

object ProfanityDetector {
    private val badWords = setOf(
        "fuck", "shit", "bitch", "asshole", "bastard", "damn", "dick", "piss"
    )

    fun containsProfanity(text: String): Boolean {
        val normalized = text.lowercase()
        val tokens = normalized.split(" ", ",", ".", "?", "!", ";", ":", "\n", "\t")
        return tokens.any { it in badWords }
    }
}
