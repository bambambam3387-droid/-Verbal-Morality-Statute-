package com.example.profanityfine

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.profanityfine.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startService() else Toast.makeText(this, "Microphone permission required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("pf", Context.MODE_PRIVATE)
        val savedName = prefs.getString("name", "John Replogle") ?: "John Replogle"
        val credits = prefs.getInt("credits", 50)

        binding.etName.setText(savedName)
        binding.tvBalance.text = "Remaining credits: $credits"

        binding.btnStart.setOnClickListener {
            prefs.edit().putString("name", binding.etName.text.toString()).apply()
            ensureMicPermissionAndStart()
        }
        binding.btnStop.setOnClickListener {
            stopService(Intent(this, ProfanityService::class.java))
        }
        binding.btnTest.setOnClickListener {
            issueCitation(savedName)
        }
        binding.btnShowLog.setOnClickListener {
            val log = prefs.getStringSet("citations", emptySet())!!.joinToString("\n")
            Toast.makeText(this, log.ifBlank { "No citations yet." }, Toast.LENGTH_LONG).show()
        }
    }

    private fun issueCitation(name: String) {
        val prefs = getSharedPreferences("pf", Context.MODE_PRIVATE)
        val credits = prefs.getInt("credits", 50)
        val newCredits = (credits - 1).coerceAtLeast(0)
        val timestamp = SimpleDateFormat("HH:mm:ss yyyy-MM-dd", Locale.getDefault()).format(Date())
        val entry = "$timestamp - $name fined 1 credit for profanity."

        val existing = prefs.getStringSet("citations", mutableSetOf())!!.toMutableSet()
        existing.add(entry)
        prefs.edit().putStringSet("citations", existing).putInt("credits", newCredits).apply()

        binding.tvBalance.text = "Remaining credits: $newCredits"
        Toast.makeText(this, "Citation added! Remaining credits: $newCredits", Toast.LENGTH_SHORT).show()
    }

    private fun ensureMicPermissionAndStart() {
        val has = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (has) startService() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startService() {
        startForegroundService(Intent(this, ProfanityService::class.java))
        Toast.makeText(this, "Listening for Verbal Morality Statute violations...", Toast.LENGTH_SHORT).show()
    }
}
