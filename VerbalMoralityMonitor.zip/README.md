# Verbal Morality Monitor (Android, Kotlin)
Fun Demolition Man–style profanity monitor. Builds via GitHub Actions.

## Build locally
- Open in Android Studio, click Run.

## Cloud build
- Push to GitHub. The included workflow builds a debug APK and uploads it as an artifact.
